package com.example.exemplojsoncomlibhttp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private ListView dadosAgendaID;
    private ListView dadosAdicionalID;
//    private final String URL = "https://jsonplaceholder.typicode.com/posts";
    private final String URL = "https://my-json-server.typicode.com/mateusneves30/teste-myjsonserver/db";
    private StringBuilder builder = null;
//    private List<User> dadosBaixados = null;
    private Contato dadosBaixados = null;
    private List<Agenda> agendaList = new ArrayList<>();
    private List<Adicional> adicionalList = new ArrayList<>();
    private ExecutorService executorService;
    private Handler handler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dadosAgendaID = findViewById(R.id.dadosAgendaID);
        dadosAdicionalID = findViewById(R.id.dadosAdicionalID);
        executorService = Executors.newSingleThreadExecutor();
        handler = new Handler(Looper.getMainLooper());
        obterDados();
    }//onCreate

    private void obterDados() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                logic();
            }
        });
    }

    public void logic() {
        Conexao conexao = new Conexao();
        InputStream inputStream = conexao.obterRespostaHTTP(URL);
        Auxilia auxilia = new Auxilia();
        String textoJSON = auxilia.converter(inputStream);
        Log.i("JSON", "doInBackground: " + textoJSON);
        Gson gson = new Gson();
        builder = new StringBuilder();
        if (textoJSON != null) {
            Type type = new TypeToken<Contato>(){}.getType();
            dadosBaixados = gson.fromJson(textoJSON, type);
            agendaList.clear();
            agendaList.addAll(dadosBaixados.getAgenda());

            adicionalList.clear();
            adicionalList.addAll(dadosBaixados.getAdicionais());

            for (int i = 0; i < dadosBaixados.getAgenda().size(); i++) {
                builder.append(dadosBaixados.getAgenda().get(i).getId()).append("\n");
                builder.append(dadosBaixados.getAgenda().get(i).getNome()).append("\n");
                builder.append(dadosBaixados.getAgenda().get(i).getTelefone()).append("\n");
            }
            for (int i = 0; i < dadosBaixados.getAdicionais().size(); i++) {
                builder.append(dadosBaixados.getAdicionais().get(i).getId()).append("\n");
                builder.append(dadosBaixados.getAdicionais().get(i).getEmail()).append("\n");
            }
            handler.post(new Runnable() {
                @Override
                public void run() {
                    ArrayAdapter<Agenda> agendaAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, agendaList);
                    dadosAgendaID.setAdapter(agendaAdapter);

                    ArrayAdapter<Adicional> adicionalAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, adicionalList);
                    dadosAdicionalID.setAdapter(adicionalAdapter);
                }
            });
        } else {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), "Não foi possível obter JSON", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

//    private class ObterDados extends AsyncTask<Void, Void, Void> {
//        @Override
//        protected Void doInBackground(Void... voids) {
//            Conexao conexao = new Conexao();
//            InputStream inputStream = conexao.obterRespostaHTTP(URL);
//            Auxilia auxilia = new Auxilia();
//            String textoJSON = auxilia.converter(inputStream);
//            Log.i("JSON", "doInBackground: "+textoJSON);
//            Gson gson = new Gson();
//            builder = new StringBuilder();
//            if(textoJSON != null){
////                Type type = new TypeToken<List<User>>(){}.getType();
//                Type type = new TypeToken<Contato>(){}.getType();
//                dadosBaixados = gson.fromJson(textoJSON,type);
////                for (int i = 0; i < dadosBaixados.size(); i++){
////                    builder.append(dadosBaixados.get(i).toString()).append("\n");
////                }//for
//                for (int i = 0; i < dadosBaixados.getAgenda().size(); i++){
//                    builder.append(dadosBaixados.getAgenda().get(i).getId()).append("\n");
//                    builder.append(dadosBaixados.getAgenda().get(i).getNome()).append("\n");
//                    builder.append(dadosBaixados.getAgenda().get(i).getTelefone()).append("\n");
//                }//for
//                for (int i = 0; i < dadosBaixados.getAdicionais().size(); i++){
//                    builder.append(dadosBaixados.getAdicionais().get(i).getId()).append("\n");
//                    builder.append(dadosBaixados.getAdicionais().get(i).getEmail()).append("\n");
//                }//for
//            }else{
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getApplicationContext(),"Não foi possível obter JSON", Toast.LENGTH_SHORT).show();
//                    }
//                });
//            }//if else
//            return null;
//        }//doInBackground
//
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            Toast.makeText(getApplicationContext(),"Download começando...", Toast.LENGTH_SHORT).show();
//        }
//
//        @Override
//        protected void onPostExecute(Void unused) {
//            super.onPostExecute(unused);
//            textViewID.setText(builder.toString());
//        }
//    }//inner class
}//class