package com.example.appmapbasic;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

public class MainActivity extends AppCompatActivity {
    private MapView map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Configuration.getInstance()
                .load(MainActivity.this, PreferenceManager
                        .getDefaultSharedPreferences(MainActivity.this));
        map = findViewById(R.id.map);

        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);

        Marker marcador1 = new Marker(map);
        GeoPoint ponto1 = new GeoPoint(41.904324, 12.454889);
        marcador1.setPosition(ponto1);
        marcador1.setTitle("Roma");
        map.getOverlays().add(marcador1);

        Marker marcador2 = new Marker(map);
        marcador2.setPosition(new GeoPoint(-23.951206, -46.338919));
        marcador2.setTitle("Vila Belmiro");
        marcador2.setDraggable(true);
//        marcador2.setIcon(getResources().getDrawable(R.drawable.santos_logo));
        marcador2.setOnMarkerDragListener(new Marker.OnMarkerDragListener() {
            @Override
            public void onMarkerDrag(Marker marker) {

            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                GeoPoint ponto = marker.getPosition();

                Toast.makeText(MainActivity.this, "Nova posição: " + ponto.getLatitude() + ", " + ponto.getLongitude() + ", ", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onMarkerDragStart(Marker marker) {
                Toast.makeText(MainActivity.this, "Vamos começar o passeio", Toast.LENGTH_SHORT).show();
            }
        });
        map.getOverlays().add(marcador2);

        map.getController().setCenter(new GeoPoint(-23.951206, -46.338919));
        map.getController().setZoom(20);
    }

    @Override
    protected void onResume() {
        super.onResume();
        map.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        map.onPause();
    }
}